# DO NOT MODIFY THESE IMPORTS
from games.chess.ai import AI
from games.chess.game import Game
from games.chess.game_object import GameObject
from games.chess.player import Player

game_version = 'cfa5f5c1685087ce2899229c04c26e39f231e897ecc8fe036b44bc22103ef801'

# <<-- Creer-Merge: init -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
# if you need to initialize this module with custom logic do so here
# <<-- /Creer-Merge: init -->>
